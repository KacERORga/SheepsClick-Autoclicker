package com.example.autoclicker;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.text.Text;

public class AutoClicker {
    private static final int[] CPS_OPTIONS = {100, 50, 25, 20, 15, 10, 5, 1};

    private static AutoClicker instance;

    private boolean enabled = false;
    private int cpsIndex = 3;
    private long nextClickTime = 0L;

    public static void init() {
        instance = new AutoClicker();
    }

    public static AutoClicker getInstance() {
        return instance;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public int getCurrentCPS() {
        return CPS_OPTIONS[cpsIndex];
    }

    public void toggle() {
        enabled = !enabled;
        nextClickTime = System.currentTimeMillis();
        notifyStatus();
    }

    public void cycleCPS() {
        cpsIndex = (cpsIndex + 1) % CPS_OPTIONS.length;
        notifyStatus();
    }

    private void notifyStatus() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        String status = enabled ? "Enabled" : "Disabled";
        String message = String.format("[AutoClicker] %s — %d CPS", status, getCurrentCPS());
        client.player.sendMessage(Text.literal(message), false);
    }

    public void tick(MinecraftClient client) {
        if (!enabled || client.player == null) return;

        long now = System.currentTimeMillis();
        if (now >= nextClickTime) {
            performAttack(client);
            nextClickTime = now + (1000 / getCurrentCPS());
        }
    }

    private void performAttack(MinecraftClient client) {
        ClientPlayerInteractionManager interactionManager = client.interactionManager;
        if (interactionManager == null) return;

        HitResult target = client.crosshairTarget;
        if (target instanceof EntityHitResult entityHit) {
            Entity entity = entityHit.getEntity();
            if (entity != null && client.player != null) {
                interactionManager.attackEntity(client.player, entity);
                client.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }
}
