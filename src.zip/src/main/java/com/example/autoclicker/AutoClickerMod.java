package com.example.autoclicker;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;

public class AutoClickerMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        AutoClicker.init();
        KeyBindings.register();

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        HudRenderCallback.EVENT.register(this::onHudRender);
    }

    private void onTick(MinecraftClient client) {
        KeyBindings.handleInput(client);
        AutoClicker.getInstance().tick(client);
    }

    private void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        AutoClicker ac = AutoClicker.getInstance();
        TextRenderer font = client.textRenderer;

        boolean enabled = ac.isEnabled();
        int color = enabled ? 0x00FF00 : 0xFF0000;

        context.drawText(font, Text.literal("AutoClicker: " + (enabled ? "ON" : "OFF")), 2, 2, color, true);
        context.drawText(font, Text.literal("CPS: " + ac.getCurrentCPS()), 2, 12, 0xFFFFFF, true);
    }
}
