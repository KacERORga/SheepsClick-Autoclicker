package com.example.autoclicker;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class KeyBindings {
    public static KeyBinding toggleKey;
    public static KeyBinding cycleKey;

    public static void register() {
        KeyBinding.Category category = KeyBinding.Category.create(
            net.minecraft.util.Identifier.of("autoclicker", "autoclicker")
        );

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.autoclicker.toggle",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_KP_ENTER,
            category
        ));
        cycleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.autoclicker.cycle",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_KP_SUBTRACT,
            category
        ));
    }

    public static void handleInput(MinecraftClient client) {
        while (toggleKey.wasPressed()) {
            AutoClicker.getInstance().toggle();
        }

        while (cycleKey.wasPressed()) {
            AutoClicker.getInstance().cycleCPS();
        }
    }
}
